import pandas as pd
import numpy as np

# Optional: Adjust pandas display options to show all rows and columns
pd.set_option('display.max_rows', None)      # Display all rows
pd.set_option('display.max_columns', None)   # Display all columns
pd.set_option('display.width', None)         # Adjust display width to fit the console
pd.set_option('display.max_colwidth', None)  # Display full content in each column

def load_daily_data(file_name):
    """
    Loads the daily CSV file into a DataFrame, sorts it by date, and resets the index.
    """
    df = pd.read_csv(file_name, parse_dates=['Date'])
    df.sort_values('Date', inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df

def load_5min_data(file_name):
    """
    Loads the 5-minute CSV file into a DataFrame, sorts it by Time in ascending order, and resets the index.
    """
    df = pd.read_csv(file_name, parse_dates=['Time'])
    df.sort_values('Time', inplace=True)  # Ensure data is sorted from earliest to latest
    df.reset_index(drop=True, inplace=True)
    return df

def load_vix_data(vix_file):
    """
    Loads the VIX data from a CSV file into a DataFrame, sorts it by date, and resets the index.
    Ensures that the 'Date' column is in datetime format.
    """
    vix_df = pd.read_csv(vix_file, parse_dates=['DATE'], dayfirst=True)
    vix_df.rename(columns={'DATE': 'Date'}, inplace=True)
    # Explicitly convert 'Date' to datetime to ensure consistency
    vix_df['Date'] = pd.to_datetime(vix_df['Date'], dayfirst=True, errors='coerce')
    # Drop rows with invalid dates if any
    vix_df.dropna(subset=['Date'], inplace=True)
    vix_df.sort_values('Date', inplace=True)
    vix_df.reset_index(drop=True, inplace=True)
    return vix_df

def calculate_day_range(day):
    """
    Calculates the trading range of a day (High - Low).
    """
    return day['High'] - day['Low']

def calculate_gap(prev_close, curr_open):
    """
    Calculates the gap between the previous day's close and the current day's open.
    """
    return curr_open - prev_close

def is_gap_valid(gap, prev_range):
    """
    Checks if the gap meets the specified conditions:
    - At least $0.20
    - Between 15% and 85% of the previous day's range
    """
    gap_abs = abs(gap)
    if gap_abs < 0.20 or prev_range == 0:
        return False
    gap_percentage = gap_abs / prev_range
    return 0.15 <= gap_percentage <= 0.85

def is_vix_valid(current_date, vix_df):
    """
    Checks if the VIX opening value on the day before the current date was between 15 and 22.
    """
    prev_date = current_date - pd.Timedelta(days=1)
    
    # Since the previous day might be a weekend or holiday, search for the last trading day
    while prev_date not in vix_df['Date'].values and prev_date > vix_df['Date'].min():
        prev_date -= pd.Timedelta(days=1)
    
    if prev_date not in vix_df['Date'].values:
        return False  # No VIX data for the previous day
    
    vix_open = vix_df.loc[vix_df['Date'] == prev_date, 'OPEN'].values[0]
    return 13.1 < vix_open < 22

def determine_trade_direction(gap):
    """
    Determines the trade direction based on the gap:
    - Gap up: Short position
    - Gap down: Long position
    """
    return 'Short' if gap > 0 else 'Long'

def get_first_5min_candle(trade_direction, date, min_df):
    """
    Retrieves the first 5-minute candle of the trading day and checks if it moves in the opposite direction of the gap.
    """
    # Filter the data for the specific trading day
    day_data = min_df[min_df['Time'].dt.date == date.date()]
    if day_data.empty:
        return False  # No data available for this day

    # Ensure there are at least two 5-minute candles to enter the trade at the second candle's open
    if len(day_data) < 2:
        return False  # Not enough data to enter the trade

    # Get the first 5-minute candle (earliest)
    first_candle = day_data.iloc[0]

    if trade_direction == 'Short':
        # Gap up: First candle should be red (downward movement)
        return first_candle['Last'] < first_candle['Open']
    else:
        # Gap down: First candle should be green (upward movement)
        return first_candle['Last'] > first_candle['Open']

def is_gap_closed_first_five_minutes(trade_direction, date, min_df, prev_close):
    """
    Checks if the gap was closed during the first five minutes of trading.
    """
    # Filter the data for the specific trading day
    day_data = min_df[min_df['Time'].dt.date == date.date()]
    if day_data.empty:
        return False  # No data available for this day

    # Ensure there is at least one 5-minute candle
    if len(day_data) < 1:
        return False  # Not enough data to check

    # Get the first 5-minute candle
    first_candle = day_data.iloc[0]

    if trade_direction == 'Short':
        # Gap up: Check if Low <= prev_close
        return first_candle['Low'] <= prev_close
    else:
        # Gap down: Check if High >= prev_close
        return first_candle['High'] >= prev_close

def get_second_5min_open(date, min_df):
    """
    Retrieves the open price of the second 5-minute candle of the trading day.
    """
    # Filter the data for the specific trading day
    day_data = min_df[min_df['Time'].dt.date == date.date()]
    if len(day_data) < 2:
        return None  # Not enough data to enter the trade

    # Get the second 5-minute candle (second earliest)
    second_candle = day_data.iloc[1]
    return second_candle['Open']

def check_gap_closure(trade_direction, curr_day, prev_close):
    """
    Checks if the gap is closed during the trading day and returns the exit price.
    """
    if trade_direction == 'Short':
        # For a short position, the gap is closed if the price reaches or falls below the previous close
        if curr_day['Low'] <= prev_close:
            exit_price = prev_close
            gap_closed = True
        else:
            exit_price = curr_day['Close']  # Use 'Close' from daily data
            gap_closed = False
    else:  # Long position
        # For a long position, the gap is closed if the price reaches or exceeds the previous close
        if curr_day['High'] >= prev_close:
            exit_price = prev_close
            gap_closed = True
        else:
            exit_price = curr_day['Close']  # Use 'Close' from daily data
            gap_closed = False
    return exit_price, gap_closed

def calculate_profit_loss(trade_direction, entry_price, exit_price, position_size):
    """
    Calculates the profit or loss of a trade.
    """
    # Calculate the number of shares bought or sold
    number_of_shares = position_size / entry_price

    if trade_direction == 'Long':
        profit_loss = number_of_shares * (exit_price - entry_price)
    else:  # Short position
        profit_loss = number_of_shares * (entry_price - exit_price)

    return profit_loss

def analyze_trades(daily_df, min_df, vix_df):
    """
    Analyzes the DataFrame for valid gap trades considering both VIX and 5-minute conditions.
    Returns a DataFrame of trades.
    """
    trades = []
    total_days = len(daily_df)

    for i in range(1, total_days):
        prev_day = daily_df.iloc[i - 1]
        curr_day = daily_df.iloc[i]

        # Check VIX condition
        if not is_vix_valid(curr_day['Date'], vix_df):
            continue  # If VIX condition is not met, do not trade

        prev_range = calculate_day_range(prev_day)
        if prev_range == 0:
            continue  # Avoid division by zero

        gap = calculate_gap(prev_day['Close'], curr_day['Open'])
        if not is_gap_valid(gap, prev_range):
            continue

        trade_direction = determine_trade_direction(gap)

        # Check the first 5-minute candle direction condition
        condition_met = get_first_5min_candle(trade_direction, curr_day['Date'], min_df)
        if not condition_met:
            continue  # Condition not met, do not enter the trade

        # Check if the gap was closed in the first five minutes
        gap_closed_first_five = is_gap_closed_first_five_minutes(trade_direction, curr_day['Date'], min_df, prev_day['Close'])
        if gap_closed_first_five:
            continue  # Gap was closed in the first five minutes, do not enter the trade

        # Get the entry price from the second 5-minute candle's open
        entry_price = get_second_5min_open(curr_day['Date'], min_df)
        if entry_price is None:
            continue  # Not enough data to enter the trade

        exit_price, gap_closed = check_gap_closure(trade_direction, curr_day, prev_day['Close'])

        trades.append({
            'Date': curr_day['Date'],
            'Trade Direction': trade_direction,
            'Entry Price': entry_price,
            'Exit Price': exit_price,
            'Gap Closed': gap_closed
        })
    return pd.DataFrame(trades)

def calculate_statistics(trades_df):
    """
    Calculates and prints the required statistics:
    - Average Gain per Trade
    - Average Loss per Trade
    - Maximum Gain per Trade and date
    - Maximum Loss per Trade and date
    """
    if trades_df.empty:
        print("No trades met the criteria.")
        return

    # Calculate Profit/Loss for each trade
    gains = trades_df[trades_df['Profit/Loss'] > 0]
    losses = trades_df[trades_df['Profit/Loss'] < 0]

    # Calculate statistics
    average_gain = gains['Profit/Loss'].mean() if not gains.empty else 0
    average_loss = losses['Profit/Loss'].mean() if not losses.empty else 0
    max_gain = gains['Profit/Loss'].max() if not gains.empty else 0
    max_loss = losses['Profit/Loss'].min() if not losses.empty else 0  # Losses are negative

    # Get the dates of maximum gain and maximum loss trades
    if not gains.empty:
        max_gain_row = gains.loc[gains['Profit/Loss'].idxmax()]
        max_gain_date = max_gain_row['Date']
    else:
        max_gain_date = None

    if not losses.empty:
        max_loss_row = losses.loc[losses['Profit/Loss'].idxmin()]
        max_loss_date = max_loss_row['Date']
    else:
        max_loss_date = None

    # Print the results
    print(f"Total Trades: {len(trades_df)}")
    print(f"Average Gain per Trade: ${average_gain:,.2f}")
    print(f"Average Loss per Trade: ${average_loss:,.2f}")
    if max_gain_date is not None:
        print(f"Maximum Gain per Trade: ${max_gain:,.2f} on {max_gain_date.date()}")
    else:
        print("No gains to report.")

    if max_loss_date is not None:
        print(f"Maximum Loss per Trade: ${max_loss:,.2f} on {max_loss_date.date()}")
    else:
        print("No losses to report.")

# === New Functions Added ===
def count_winning_trades(trades_df):
    """
    Returns the number of trades with Profit/Loss greater than zero.
    """
    return trades_df[trades_df['Profit/Loss'] > 0].shape[0]

def count_losing_trades(trades_df):
    """
    Returns the number of trades with Profit/Loss less than zero.
    """
    return trades_df[trades_df['Profit/Loss'] < 0].shape[0]
# === End of New Functions ===

def simulate_trading(trades_df, initial_investment):
    """
    Simulates trading with a given initial investment and returns the final amount.
    """
    if trades_df.empty:
        print("No trades to simulate.")
        return initial_investment

    current_amount = initial_investment
    trade_results = []

    for index, row in trades_df.iterrows():
        trade_direction = row['Trade Direction']
        entry_price = row['Entry Price']
        exit_price = row['Exit Price']

        # Calculate profit or loss based on current amount
        profit_loss = calculate_profit_loss(trade_direction, entry_price, exit_price, initial_investment)

        # Update current amount
        current_amount += profit_loss

        # Store the result
        trade_results.append(profit_loss)

    total_profit_loss = sum(trade_results)
    final_amount = current_amount

    print(f"Initial Investment: ${initial_investment:,.2f}")
    print(f"Total Trades: {len(trades_df)}")
    print(f"Total Profit/Loss from All Trades: ${total_profit_loss:,.2f}")
    print(f"Final Amount after All Trades: ${final_amount:,.2f}")

    return final_amount

def analyze_spy_gaps(daily_file, min_file, vix_file, initial_investment):
    """
    Main function that orchestrates the gap analysis and trading simulation.
    """
    daily_df = load_daily_data(daily_file)
    min_df = load_5min_data(min_file)
    vix_df = load_vix_data(vix_file)

    # Ensure 'Time' column is in datetime format
    if not np.issubdtype(min_df['Time'].dtype, np.datetime64):
        min_df['Time'] = pd.to_datetime(min_df['Time'], errors='coerce')

    # Drop rows with invalid datetime
    min_df.dropna(subset=['Time'], inplace=True)

    trades_df = analyze_trades(daily_df, min_df, vix_df)

    if trades_df.empty:
        print("No trades met the criteria after applying all conditions.")
        return trades_df, initial_investment

    # Initialize a column for Profit/Loss
    trades_df['Profit/Loss'] = 0.0

    # Calculate profit/loss for each trade based on initial investment
    for index, row in trades_df.iterrows():
        trades_df.at[index, 'Profit/Loss'] = calculate_profit_loss(
            row['Trade Direction'],
            row['Entry Price'],
            row['Exit Price'],
            initial_investment
        )

    calculate_statistics(trades_df)
    final_amount = simulate_trading(trades_df, initial_investment)
    return trades_df, final_amount

# Example usage:
# Replace 'D6CK32X6.csv' with the path to your daily SPY data CSV file.
# Replace '5_MINUTES_DATA.csv' with the path to your 5-minute interval SPY data CSV file.
# Replace 'VIX_History.csv' with the path to your VIX data CSV file.
# Set your initial investment amount
initial_investment = 16000  # $16,000 initial investment

# Analyze the gaps and simulate trading
trades, final_amount = analyze_spy_gaps('D6CK32X6.csv', '5_MINUTES_DATA.csv', 'VIX_History.csv', initial_investment)

# Display trade details (prints the entire DataFrame)
print("\nTrade Details:")
print(trades.to_string())  # Prints the entire DataFrame without truncation

# === New Lines Added ===
# Calculate the number of winning and losing trades
num_winning_trades = count_winning_trades(trades)
num_losing_trades = count_losing_trades(trades)

# Print the number of winning and losing trades
print(f"\nNumber of Winning Trades: {num_winning_trades}")
print(f"Number of Losing Trades: {num_losing_trades}")
# === End of New Lines ===
